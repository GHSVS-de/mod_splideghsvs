<?php
\defined('_JEXEC') or die;


echo "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb";
?>
<?php echo $myId; ?>
<div id="secondarySlider_<?php echo $myId; ?>" class="splide">
	<div class="splide__track">
		<ul class="splide__list">
			<li class="splide__slide">
				<img src="images/9491_463219517047075_644044600_n.jpg">
			</li>
			<li class="splide__slide">
				<img src="images/9491_463219517047075_644044600_n.jpg">
			</li>
			<li class="splide__slide">
				<img src="images/9491_463219517047075_644044600_n.jpg">
			</li>
		</ul>
	</div>
</div>
